class ImageGallery {
    constructor() {
        this.images = [];
        this.filteredImages = [];
        this.currentFilter = 'all';
        this.currentLightboxIndex = 0;
        this.imagesPerLoad = 12;
        this.currentLoadedImages = 0;

        this.initializeElements();
        this.generateSampleImages();
        this.bindEvents();
        this.loadInitialImages();
    }

    initializeElements() {
        this.galleryGrid = document.getElementById('galleryGrid');
        this.lightbox = document.getElementById('lightbox');
        this.lightboxImage = document.getElementById('lightboxImage');
        this.lightboxTitle = document.getElementById('lightboxTitle');
        this.lightboxDescription = document.getElementById('lightboxDescription');
        this.lightboxCategory = document.getElementById('lightboxCategory');
        this.lightboxCounter = document.getElementById('lightboxCounter');
        this.loadMoreBtn = document.getElementById('loadMoreBtn');
        this.searchInput = document.getElementById('searchInput');
        this.loadingSpinner = document.getElementById('loadingSpinner');

        this.filterButtons = document.querySelectorAll('.filter-btn');
        this.lightboxClose = document.getElementById('lightboxClose');
        this.lightboxPrev = document.getElementById('lightboxPrev');
        this.lightboxNext = document.getElementById('lightboxNext');
    }

    generateSampleImages() {
        // Sample image data with Unsplash API for high-quality images
        const categories = ['nature', 'architecture', 'people', 'technology'];
        const imageData = [
            // Nature Images
            { category: 'nature', title: 'Mountain Sunrise', description: 'Breathtaking sunrise over mountain peaks', id: 1 },
            { category: 'nature', title: 'Forest Path', description: 'Mysterious path through ancient forest', id: 2 },
            { category: 'nature', title: 'Ocean Waves', description: 'Powerful waves crashing on rocky shore', id: 3 },
            { category: 'nature', title: 'Desert Landscape', description: 'Vast desert with golden sand dunes', id: 4 },
            { category: 'nature', title: 'Waterfall', description: 'Majestic waterfall in tropical paradise', id: 5 },
            { category: 'nature', title: 'Aurora Borealis', description: 'Northern lights dancing in the sky', id: 6 },

            // Architecture Images
            { category: 'architecture', title: 'Modern Skyscraper', description: 'Glass and steel reaching for the sky', id: 7 },
            { category: 'architecture', title: 'Ancient Cathedral', description: 'Gothic architecture from medieval times', id: 8 },
            { category: 'architecture', title: 'Bridge Design', description: 'Engineering marvel spanning the river', id: 9 },
            { category: 'architecture', title: 'Urban Geometry', description: 'Abstract patterns in city buildings', id: 10 },
            { category: 'architecture', title: 'Historic Castle', description: 'Medieval fortress on hilltop', id: 11 },
            { category: 'architecture', title: 'Modern Museum', description: 'Contemporary architectural masterpiece', id: 12 },

            // People Images
            { category: 'people', title: 'Street Portrait', description: 'Candid moment in urban setting', id: 13 },
            { category: 'people', title: 'Cultural Festival', description: 'Celebration of traditions and heritage', id: 14 },
            { category: 'people', title: 'Musician Performance', description: 'Artist lost in musical expression', id: 15 },
            { category: 'people', title: 'Family Gathering', description: 'Precious moments with loved ones', id: 16 },
            { category: 'people', title: 'Adventure Sports', description: 'Extreme sports and human courage', id: 17 },
            { category: 'people', title: 'Workplace Innovation', description: 'Collaboration and creativity at work', id: 18 },

            // Technology Images
            { category: 'technology', title: 'Circuit Board Art', description: 'Beauty in electronic complexity', id: 19 },
            { category: 'technology', title: 'Smartphone Innovation', description: 'Latest mobile technology showcase', id: 20 },
            { category: 'technology', title: 'Data Visualization', description: 'Information transformed into art', id: 21 },
            { category: 'technology', title: 'Robotic Engineering', description: 'Future of automation and AI', id: 22 },
            { category: 'technology', title: 'Virtual Reality', description: 'Immersive digital experiences', id: 23 },
            { category: 'technology', title: 'Space Technology', description: 'Exploring the final frontier', id: 24 }
        ];

        // Generate image objects with Unsplash URLs
        this.images = imageData.map((item, index) => ({
            id: item.id,
            title: item.title,
            description: item.description,
            category: item.category,
            url: `https://picsum.photos/400/300?random=${item.id}`,
            thumbnail: `https://picsum.photos/300/250?random=${item.id}`
        }));

        this.filteredImages = [...this.images];
    }

    bindEvents() {
        // Filter buttons
        this.filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.handleFilterChange(e.target.dataset.filter);
            });
        });

        // Search functionality
        this.searchInput.addEventListener('input', (e) => {
            this.handleSearch(e.target.value);
        });

        // Load more button
        this.loadMoreBtn.addEventListener('click', () => {
            this.loadMoreImages();
        });

        // Lightbox events
        this.lightboxClose.addEventListener('click', () => {
            this.closeLightbox();
        });

        this.lightboxPrev.addEventListener('click', () => {
            this.navigateLightbox(-1);
        });

        this.lightboxNext.addEventListener('click', () => {
            this.navigateLightbox(1);
        });

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (this.lightbox.classList.contains('active')) {
                switch (e.key) {
                    case 'Escape':
                        this.closeLightbox();
                        break;
                    case 'ArrowLeft':
                        this.navigateLightbox(-1);
                        break;
                    case 'ArrowRight':
                        this.navigateLightbox(1);
                        break;
                }
            }
        });

        // Close lightbox on background click
        this.lightbox.addEventListener('click', (e) => {
            if (e.target === this.lightbox) {
                this.closeLightbox();
            }
        });
    }

    handleFilterChange(filter) {
        // Update active button
        this.filterButtons.forEach(btn => btn.classList.remove('active'));
        document.querySelector(`[data-filter="${filter}"]`).classList.add('active');

        this.currentFilter = filter;
        this.applyFilters();
    }

    handleSearch(searchTerm) {
        this.searchTerm = searchTerm.toLowerCase();
        this.applyFilters();
    }

    applyFilters() {
        // Filter by category
        let filtered = this.currentFilter === 'all' ? [...this.images] :
            this.images.filter(img => img.category === this.currentFilter);

        // Filter by search term
        if (this.searchTerm) {
            filtered = filtered.filter(img =>
                img.title.toLowerCase().includes(this.searchTerm) ||
                img.description.toLowerCase().includes(this.searchTerm) ||
                img.category.toLowerCase().includes(this.searchTerm)
            );
        }

        this.filteredImages = filtered;
        this.currentLoadedImages = 0;
        this.clearGallery();
        this.loadInitialImages();
    }

    clearGallery() {
        // Add fade out animation
        const items = this.galleryGrid.querySelectorAll('.gallery-item');
        items.forEach(item => {
            item.classList.add('fade-out');
        });

        setTimeout(() => {
            this.galleryGrid.innerHTML = '';
        }, 300);
    }

    loadInitialImages() {
        this.showLoading();

        setTimeout(() => {
            this.loadMoreImages();
            this.hideLoading();
        }, 500);
    }

    loadMoreImages() {
        const startIndex = this.currentLoadedImages;
        const endIndex = Math.min(startIndex + this.imagesPerLoad, this.filteredImages.length);
        const imagesToLoad = this.filteredImages.slice(startIndex, endIndex);

        imagesToLoad.forEach((image, index) => {
            setTimeout(() => {
                this.createImageElement(image, startIndex + index);
            }, index * 100); // Stagger the animations
        });

        this.currentLoadedImages = endIndex;

        // Hide load more button if all images are loaded
        if (this.currentLoadedImages >= this.filteredImages.length) {
            this.loadMoreBtn.style.display = 'none';
        } else {
            this.loadMoreBtn.style.display = 'block';
        }
    }

    createImageElement(image, index) {
        const galleryItem = document.createElement('div');
        galleryItem.className = 'gallery-item';
        galleryItem.dataset.index = index;

        galleryItem.innerHTML = `
            <img src="${image.thumbnail}" alt="${image.title}" loading="lazy">
            <div class="gallery-overlay">
                <h3 class="gallery-title">${image.title}</h3>
                <p class="gallery-description">${image.description}</p>
                <span class="gallery-category">${this.capitalizeFirst(image.category)}</span>
            </div>
        `;

        // Add click event for lightbox
        galleryItem.addEventListener('click', () => {
            this.openLightbox(index);
        });

        this.galleryGrid.appendChild(galleryItem);

        // Trigger animation
        setTimeout(() => {
            galleryItem.classList.add('fade-in');
        }, 50);
    }

    openLightbox(index) {
        this.currentLightboxIndex = index;
        const image = this.filteredImages[index];

        this.lightboxImage.src = image.url;
        this.lightboxTitle.textContent = image.title;
        this.lightboxDescription.textContent = image.description;
        this.lightboxCategory.textContent = this.capitalizeFirst(image.category);
        this.lightboxCounter.textContent = `${index + 1} / ${this.filteredImages.length}`;

        this.lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';

        // Preload adjacent images
        this.preloadAdjacentImages(index);
    }

    closeLightbox() {
        this.lightbox.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    navigateLightbox(direction) {
        const newIndex = this.currentLightboxIndex + direction;

        if (newIndex >= 0 && newIndex < this.filteredImages.length) {
            this.openLightbox(newIndex);
        }
    }

    preloadAdjacentImages(index) {
        // Preload previous and next images for smooth navigation
        const preloadIndexes = [index - 1, index + 1];

        preloadIndexes.forEach(i => {
            if (i >= 0 && i < this.filteredImages.length) {
                const img = new Image();
                img.src = this.filteredImages[i].url;
            }
        });
    }

    showLoading() {
        this.loadingSpinner.style.display = 'flex';
    }

    hideLoading() {
        this.loadingSpinner.style.display = 'none';
    }

    capitalizeFirst(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
}

// Initialize gallery when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const gallery = new ImageGallery();

    // Add some console messages for developers
    console.log(' Advanced Image Gallery by Athini Zolela');
    console.log(' Features: Responsive design, lightbox, filters, search, keyboard navigation');
    console.log(' Keyboard shortcuts: ESC (close), Arrow keys (navigate)');

    // Add performance monitoring
    window.addEventListener('load', () => {
        const loadTime = performance.now();
        console.log(`⚡ Gallery loaded in ${Math.round(loadTime)}ms`);
    });
});

// Add smooth scrolling for better UX
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});